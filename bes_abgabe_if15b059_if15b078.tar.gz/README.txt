Vehicle Test Grid
Gruppenarbeit: Auerbeck(if15b059), Gjurgjej(if15b078)

Reihenfolge, damit die Programme korrekt funktionieren:
1) ./gridserver -x [int] -y [int]
2) ./griddisplay
3) ./vehicleclient [char] (maximal 26 Clients bzw. x*y des Servers)

Vehicleclient Befehle:
Fahren:
	N
	E
	S
	W
Programm beenden:
	T

